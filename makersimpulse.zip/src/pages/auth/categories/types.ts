export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  created_at?: string;
}