import React from 'react';
import { SettingsForm } from '../SettingsForm';

export const ThemeSettingsTab = () => {
  return <SettingsForm />;
};