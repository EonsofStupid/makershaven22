import React from 'react';

export const ActivitySection = () => {
  return (
    <div className="space-y-4">
      {/* Activity section will be implemented here */}
    </div>
  );
};